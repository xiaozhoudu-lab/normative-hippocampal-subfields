
load_normative_grid <- function(grid_path = file.path("data", "hippo_subfields_normative_quantile_grid.csv.gz")) {
  read.csv(grid_path, check.names = FALSE, stringsAsFactors = FALSE)
}

normative_centile <- function(grid, hemisphere, roi, sex, age, volume) {
  q_cols <- grep("^q[0-9]{3}$", names(grid), value = TRUE)
  probs <- as.numeric(sub("^q", "", q_cols)) / 1000
  key <- grid[
    grid$hemisphere == hemisphere &
      grid$roi == roi &
      grid$sex == sex,
  ]
  if (nrow(key) < 2) {
    stop("No matching normative curve for hemisphere/roi/sex.")
  }
  if (age < min(key$age, na.rm = TRUE) || age > max(key$age, na.rm = TRUE)) {
    warning("Age is outside the released grid range; edge extrapolation is used.")
  }
  q_at_age <- vapply(q_cols, function(col) {
    approx(key$age, key[[col]], xout = age, rule = 2, ties = mean)$y
  }, numeric(1))
  ord <- order(q_at_age, probs)
  q_at_age <- q_at_age[ord]
  probs <- probs[ord]
  keep <- !duplicated(q_at_age)
  q_at_age <- q_at_age[keep]
  probs <- probs[keep]
  p <- approx(q_at_age, probs, xout = volume, rule = 2, ties = mean)$y
  z <- qnorm(p)
  data.frame(
    hemisphere = hemisphere,
    roi = roi,
    sex = sex,
    age = age,
    volume = volume,
    centile = p,
    z_score = z
  )
}

score_normative_file <- function(input_csv, output_csv, grid_path = file.path("data", "hippo_subfields_normative_quantile_grid.csv.gz")) {
  grid <- load_normative_grid(grid_path)
  x <- read.csv(input_csv, check.names = FALSE, stringsAsFactors = FALSE)
  required <- c("hemisphere", "roi", "sex", "age", "volume")
  missing <- setdiff(required, names(x))
  if (length(missing)) {
    stop("Input is missing columns: ", paste(missing, collapse = ", "))
  }
  scored <- do.call(rbind, lapply(seq_len(nrow(x)), function(i) {
    normative_centile(
      grid = grid,
      hemisphere = x$hemisphere[i],
      roi = x$roi[i],
      sex = x$sex[i],
      age = x$age[i],
      volume = x$volume[i]
    )
  }))
  out <- cbind(x, centile = scored$centile, z_score = scored$z_score)
  write.csv(out, output_csv, row.names = FALSE)
  invisible(out)
}

