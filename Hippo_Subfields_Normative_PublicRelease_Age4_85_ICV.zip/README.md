# Hippo Subfields Normative Public Release

Release label: Age 4-85 ICV-adjusted measure

This public package contains age- and sex-specific normative quantile grids for hippocampal subfield measures.

## Why no RDS model file?

The internal RDS objects are not suitable for public release because they contain fitted model internals and subject-level information. This package instead releases a dense quantile grid. It preserves practical scoring ability while omitting subject rows, site labels, identifiers, and sample-size fields.

## Files

- `data/hippo_subfields_normative_quantile_grid.csv.gz`: public quantile grid by hemisphere, ROI, sex, and age.
- `figures/normative_curves_public.pdf`: public curve atlas for visual inspection.
- `R/score_normative_centile.R`: helper functions for centile and z-score calculation.
- `examples/example_subjects.csv`: input template.
- `data/release_metadata.csv`: public metadata without sample counts.
- `MANIFEST.csv`: release contents audit.

## Grid columns

`hemisphere`, `roi`, `sex`, and `age` identify the curve. Quantile columns are named as `q001`, `q025`, `q500`, etc., where the number is probability times 1000. For example, `q025` is the 2.5th percentile and `q500` is the median.

## R usage

```r
source('R/score_normative_centile.R')
grid <- load_normative_grid()
normative_centile(grid, hemisphere='lh', roi='CA1', sex='Female', age=30, volume=600)

score_normative_file(
  input_csv='examples/example_subjects.csv',
  output_csv='examples/example_subjects_scored.csv'
)
```

Input files for `score_normative_file()` must contain `hemisphere`, `roi`, `sex`, `age`, and `volume` columns.

## Privacy boundary

This package intentionally excludes raw/internal RDS objects, training tables, matched lists, diagnostic score tables, subject identifiers, site labels, and any explicit training or scored sample counts.
